// UserDlg.cpp : implementation file
//

#include "stdafx.h"
#include "RainbowGUI.h"
#include "UserDlg.h"
#include "..\SharedMemory.h"
#include "..\CommonDefinition.h"

// SharedMemory variable
extern PSHARED_DATA pSharedMemory;

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CUserDlg property page

IMPLEMENT_DYNCREATE(CUserDlg, CPropertyPage)

CUserDlg::CUserDlg() : CPropertyPage(CUserDlg::IDD)
{
	//{{AFX_DATA_INIT(CUserDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CUserDlg::~CUserDlg()
{
}

void CUserDlg::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CUserDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CUserDlg, CPropertyPage)
	//{{AFX_MSG_MAP(CUserDlg)
	ON_BN_CLICKED(IDC_TEST1, OnTest1)
	ON_BN_CLICKED(IDC_TEST2, OnTest2)
	ON_BN_CLICKED(IDC_TEST3, OnTest3)
	ON_BN_CLICKED(IDC_TEST4, OnTest4)
	ON_BN_CLICKED(IDC_TEST5, OnTest5)
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	ON_BN_CLICKED(IDC_ROLL_DAMPING_SET, OnRollDampingSet)
	ON_BN_CLICKED(IDC_PITCH_DAMPING_SET, OnPitchDampingSet)
	ON_BN_CLICKED(IDC_BUTTON_X, OnButtonX)
	ON_BN_CLICKED(IDC_DSP_GAIN_SET, OnDspGainSet)
	ON_BN_CLICKED(IDC_THROW_BUTTON, OnThrow)
	ON_BN_CLICKED(IDC_BALL_BUTTON, OnBall)
	ON_BN_CLICKED(IDC_RightWristFetOn, OnRightWristFetOn)
	ON_BN_CLICKED(IDC_RwCtrlOn, OnRwCtrlOn)
	ON_BN_CLICKED(IDC_Init_Hand, OnInitHand)
	ON_BN_CLICKED(IDC_Close_Finger, OnCloseFinger)
	ON_BN_CLICKED(IDC_Open_Finger, OnOpenFinger)
	ON_BN_CLICKED(IDC_Finger_Off, OnFingerOff)
	ON_BN_CLICKED(IDC_WAVE, OnWave)
	ON_BN_CLICKED(IDC_WaveLoop, OnWaveLoop)
	ON_BN_CLICKED(IDC_WST_FET_ON, OnWstFetOn)
	ON_BN_CLICKED(IDC_WST_CTRL_On, OnWSTCTRLOn)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CUserDlg message handlers

void CUserDlg::OnTest1() 
{
	// TODO: Add your control notification handler code here
	if(pSharedMemory->CommandFlag == NO_ACT)
	{
		pSharedMemory->CommandData = 1;
		pSharedMemory->CommandFlag = BEEP;
	}
	else AfxMessageBox("Other Command is activated..!!");
}

void CUserDlg::OnTest2() 
{
	// TODO: Add your control notification handler code here
	if(pSharedMemory->CommandFlag == NO_ACT)
	{
		pSharedMemory->CommandData = 2;
		pSharedMemory->CommandFlag = BEEP;
	}
	else AfxMessageBox("Other Command is activated..!!");
}

void CUserDlg::OnTest3() 
{
	// TODO: Add your control notification handler code here
	if(pSharedMemory->CommandFlag == NO_ACT)
	{
		pSharedMemory->CommandData = 3;
		pSharedMemory->CommandFlag = BEEP;
	}
	else AfxMessageBox("Other Command is activated..!!");	
}

void CUserDlg::OnTest4() 
{
	// TODO: Add your control notification handler code here
	if(pSharedMemory->CommandFlag == NO_ACT)
	{
		pSharedMemory->CommandData = 4;
		pSharedMemory->CommandFlag = BEEP;
	}
	else AfxMessageBox("Other Command is activated..!!");
}

void CUserDlg::OnTest5() 
{
	// TODO: Add your control notification handler code here
	if(pSharedMemory->CommandFlag == NO_ACT)
	{
		pSharedMemory->CommandData = 0;
		pSharedMemory->CommandFlag = BEEP;
	}
	else AfxMessageBox("Other Command is activated..!!");
}

void CUserDlg::OnButton1() 
{
	// TODO: Add your control notification handler code here
	unsigned char i;
	if(pSharedMemory->CommandFlag == NO_ACT)
	{
		for(i=0 ; i<=LWP ; i++)
		{
			pSharedMemory->JointID = i;
			pSharedMemory->CommandFlag = PRINT_JOINT_PARAMETER;
			Sleep(200);
		}
	}
	else AfxMessageBox("Other Command is activated..!!");
}

void CUserDlg::OnRollDampingSet() 
{
	// TODO: Add your control notification handler code here
	CString strText;
	
	if(pSharedMemory->CommandFlag == NO_ACT)
	{
		GetDlgItem(IDC_ROLL_OVERALL)->GetWindowText(strText);
		pSharedMemory->CommandData = 0x01;
		pSharedMemory->CommandDataFloat[0] = (float)atof(strText);
		GetDlgItem(IDC_ROLL_P)->GetWindowText(strText);
		pSharedMemory->CommandDataFloat[1] = (float)atof(strText);
		GetDlgItem(IDC_ROLL_V)->GetWindowText(strText);
		pSharedMemory->CommandDataFloat[2] = (float)atof(strText);

		pSharedMemory->CommandFlag = SET_DAMPING_GAIN;
		
	}
	else AfxMessageBox("Other Command is activated..!!"); 
}

void CUserDlg::OnPitchDampingSet() 
{
	// TODO: Add your control notification handler code here
	CString strText;
	
	if(pSharedMemory->CommandFlag == NO_ACT)
	{
		GetDlgItem(IDC_PITCH_OVERALL)->GetWindowText(strText);
		pSharedMemory->CommandData = 0x01;
		pSharedMemory->CommandDataFloat[0] = (float)atof(strText);
		GetDlgItem(IDC_PITCH_P)->GetWindowText(strText);
		pSharedMemory->CommandDataFloat[1] = (float)atof(strText);
		GetDlgItem(IDC_PITCH_V)->GetWindowText(strText);
		pSharedMemory->CommandDataFloat[2] = (float)atof(strText);
		
		pSharedMemory->CommandFlag = SET_DAMPING_GAIN;
		
	}
	else AfxMessageBox("Other Command is activated..!!"); 
}

BOOL CUserDlg::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	// TODO: Add extra initialization here
	
	GetDlgItem(IDC_PITCH_OVERALL)->SetWindowText("0.2");
	GetDlgItem(IDC_PITCH_P)->SetWindowText("1.0");
	GetDlgItem(IDC_PITCH_V)->SetWindowText("0.4");

	GetDlgItem(IDC_ROLL_OVERALL)->SetWindowText("0.2");
	GetDlgItem(IDC_ROLL_P)->SetWindowText("1.0");
	GetDlgItem(IDC_ROLL_V)->SetWindowText("0.5");

	GetDlgItem(IDC_DSP)->SetWindowText("1.0");

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CUserDlg::OnButtonX() 
{
	// TODO: Add your control notification handler code here
	
}

void CUserDlg::OnDspGainSet() 
{
	// TODO: Add your control notification handler code here
	CString strText;
	
	if(pSharedMemory->CommandFlag == NO_ACT)
	{
		GetDlgItem(IDC_DSP)->GetWindowText(strText);
		pSharedMemory->CommandDataFloat[0] = (float)atof(strText);
		pSharedMemory->CommandFlag = SET_DSP_GAIN;
		
	}
	else AfxMessageBox("Other Command is activated..!!"); 
}

void CUserDlg::OnThrow() 
{
	// TODO: Add your control notification handler code here


    float ship, sLhy, sLhr, sLhp, sLnp, sLap, sLar, sRhy, sRhr, sRhp, sRnp, sRap, sRar, sLsp, sLsr, sLsy, sLe, sRsp, sRsr, sRsy, sRe, sLwp, sLwr, sRwp, sRwr, sRwy, sRhn;


    FILE *fp, *fp2, *fp3;
    //fp = fopen("setup.txt","r");
    //fp2 = fopen("throwball.txt","r");

	fp = fopen("huboThrowR2.setup.hubop","r");
    fp2 = fopen("huboThrowR2.main.hubop","r");
	fp3 = fopen("huboWave.main.hubop","r");


	pSharedMemory->dml_main_size	=	542;
	pSharedMemory->dml_setup_size	=	300;
	pSharedMemory->dml_wave_size	=	400;
	pSharedMemory->dml_dof_size		=	27;
	pSharedMemory->dml_rwp_ready	=	0.0;
	pSharedMemory->dml_rwp_trigger	=	25.0;
	pSharedMemory->dml_trigger_t	=	297;//296;//295;  //305 (exact)
	pSharedMemory->dml_pre_stop		=	200;

	int theTrigger	=	pSharedMemory->dml_trigger_t;
	float tready	=	pSharedMemory->dml_rwp_ready;
	float ttrigger	=	pSharedMemory->dml_rwp_trigger;
	
	int mainSize	= pSharedMemory->dml_main_size;
	int setupSize	= pSharedMemory->dml_setup_size;
	int waveSize	= pSharedMemory->dml_wave_size;
	int dofSize		= pSharedMemory->dml_dof_size;




	 for (int ni=0;ni<setupSize;ni++)
	 { 
		 for(int nni=0;nni<dofSize;nni++){
		 pSharedMemory->npos[ni][nni] = 0.0;}
	 }

	  for (int ni2=0;ni2<mainSize;ni2++)
	 { 
		 for(int nni2=0;nni2<dofSize;nni2++){
		 pSharedMemory->npos2[ni2][nni2] = 0.0;}
	 }

	  for (int ni3=0;ni3<waveSize;ni3++)
	 { 
		 for(int nni3=0;nni3<dofSize;nni3++){
		 pSharedMemory->npos3[ni3][nni3] = 0.0;}
	 }

	int ti = 0;
	for (int si=0;si<setupSize;si++){
	         
   fscanf(fp,"%f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f",&ship, &sLhy, &sLhr, &sLhp, &sLnp, &sLap, &sLar, &sRhy, &sRhr, &sRhp, &sRnp, &sRap, &sRar, &sLsp, &sLsr, &sLsy, &sLe, &sRsp, &sRsr, &sRsy, &sRe, &sLwp, &sLwr, &sRwp, &sRwr, &sRwy, &sRhn);		

	    pSharedMemory->npos[si][0] = 0.0;//((-1)*ship)* (180.0/3.14);
    	pSharedMemory->npos[si][1] =  ((1)*sLhy)* (180.0/3.14);
    	pSharedMemory->npos[si][2] =  ((1)*sLhr)* (180.0/3.14)*(-1.0);
    	pSharedMemory->npos[si][3] =  ((1)*sLhp)* (180.0/3.14)*(-1.0) *(1.0);
    	pSharedMemory->npos[si][4] =  ((1))*sLnp* (180.0/3.14);
    	pSharedMemory->npos[si][5] =  ((1)*sLap)* (180.0/3.14)*(-1.0);
    	pSharedMemory->npos[si][6] =  ((1)*sLar)* (180.0/3.14)*(-1.0);
    	pSharedMemory->npos[si][7] =  ((1)*sRhy)* (180.0/3.14);
    	pSharedMemory->npos[si][8] = ((1)*sRhr)* (180.0/3.14); 
    	pSharedMemory->npos[si][9] = ((1)*sRhp)* (180.0/3.14)*(-1.0)*(1.0);
    	pSharedMemory->npos[si][10] =  ((1)*sRnp)* (180.0/3.14);
    	pSharedMemory->npos[si][11] =  ((1)*sRap)* (180.0/3.14)*(-1.0);
    	pSharedMemory->npos[si][12] = ((1)*sRar)* (180.0/3.14)*(-1.0);

		pSharedMemory->npos[si][13] = ((-1)*sLsp)* (180.0/3.14);
    	pSharedMemory->npos[si][14] = ((-1))*sLsr* (180.0/3.14) - (10.0);
    	pSharedMemory->npos[si][15] =  ((-1)*sLsy)* (180.0/3.14) -30.01;	// hand
    	pSharedMemory->npos[si][16] = ((-1)*sLe)* (180.0/3.14) +(18.0) + 30.0;
    	pSharedMemory->npos[si][17] =  ((-1)*sRsp)* (180.0/3.14);
    	pSharedMemory->npos[si][18] = ((-1)*sRsr)* (180.0/3.14) + (10.0);
    	pSharedMemory->npos[si][19] = ((1)*sRsy)* (180.0/3.14) - 45.0;
    	pSharedMemory->npos[si][20] =  ((-1)*sRe)* (180.0/3.14)+(18.0) + 10.0;	// hand
    	pSharedMemory->npos[si][21] =  0;//((1)*sLwp)* (180.0/3.14);
    	pSharedMemory->npos[si][22] =  0;//((-1)*sLwr)* (180.0/3.14);
	    pSharedMemory->npos[si][23] = 30.0; //RWY  //((1)*sRwp)* (180.0/3.14);
    	pSharedMemory->npos[si][24] = pSharedMemory->dml_rwp_ready;//((-1)*sRwr)* (180.0/3.14);

    }



   for (int ssi=0;ssi<mainSize;ssi++){
	         
   fscanf(fp2,"%f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f",&ship, &sLhy, &sLhr, &sLhp, &sLnp, &sLap, &sLar, &sRhy, &sRhr, &sRhp, &sRnp, &sRap, &sRar, &sLsp, &sLsr, &sLsy, &sLe, &sRsp, &sRsr, &sRsy, &sRe, &sLwp, &sLwr, &sRwp, &sRwr, &sRwy, &sRhn);		

	    pSharedMemory->npos2[ssi][0] = 0.0;//((1)*ship)* (180.0/3.14);
    	pSharedMemory->npos2[ssi][1] =  ((1)*sLhy)* (180.0/3.14);
    	pSharedMemory->npos2[ssi][2] =  ((1)*sLhr)* (180.0/3.14)*(-1.0);
    	pSharedMemory->npos2[ssi][3] =  ((1)*sLhp)* (180.0/3.14)*(-1.0) *(1.0);
    	pSharedMemory->npos2[ssi][4] =  ((1))*sLnp* (180.0/3.14);
    	pSharedMemory->npos2[ssi][5] =  ((1)*sLap)* (180.0/3.14)*(-1.0);
    	pSharedMemory->npos2[ssi][6] =  ((1)*sLar)* (180.0/3.14)*(-1.0);
    	pSharedMemory->npos2[ssi][7] =  ((1)*sRhy)* (180.0/3.14);
    	pSharedMemory->npos2[ssi][8] = ((1)*sRhr)* (180.0/3.14); 
    	pSharedMemory->npos2[ssi][9] = ((1)*sRhp)* (180.0/3.14)*(-1.0)*(1.0);
    	pSharedMemory->npos2[ssi][10] =  ((1)*sRnp)* (180.0/3.14);
    	pSharedMemory->npos2[ssi][11] =  ((1)*sRap)* (180.0/3.14)*(-1.0);
    	pSharedMemory->npos2[ssi][12] = ((1)*sRar)* (180.0/3.14)*(-1.0);

		pSharedMemory->npos2[ssi][13] = ((-1)*sLsp)* (180.0/3.14);
    	pSharedMemory->npos2[ssi][14] = ((-1))*sLsr* (180.0/3.14) - (10.0);
    	pSharedMemory->npos2[ssi][15] =  ((-1)*sLsy)* (180.0/3.14) - 30.01;	// hand;
    	pSharedMemory->npos2[ssi][16] = ((-1)*sLe)* (180.0/3.14) +(18.0) + 30.0;
    	pSharedMemory->npos2[ssi][17] =  ((-1)*sRsp)* (180.0/3.14);
    	pSharedMemory->npos2[ssi][18] = ((-1)*sRsr)* (180.0/3.14) + (10.0);
    	pSharedMemory->npos2[ssi][19] = ((1)*sRsy)* (180.0/3.14) - 45.0;
    	pSharedMemory->npos2[ssi][20] =  ((-1)*sRe)* (180.0/3.14)+(18.0) + 10.0;		// hand
    	pSharedMemory->npos2[ssi][21] =  0;//((1)*sLwp)* (180.0/3.14);
    	pSharedMemory->npos2[ssi][22] =  0;//((-1)*sLwr)* (180.0/3.14);
		
		if( ssi < 80 )
		{
			pSharedMemory->npos2[ssi][23] = 30.0 + (float)ssi; //RWY//((-1)*sRwr)* (180.0/3.14);
			pSharedMemory->npos2[ssi][25] = (float)ssi * -0.7;
		}
		else
		{
			pSharedMemory->npos2[ssi][23] = 110.0; //RWY//((-1)*sRwr)* (180.0/3.14);
			pSharedMemory->npos2[ssi][25] = 60.0 * 0.7; //RWY//((-1)*sRwr)* (180.0/3.14);
		}

		if( ssi > mainSize - 60 )
		{
			pSharedMemory->npos2[ssi][25] = ((float)mainSize - (float)ssi) * -0.7;
		}

		if( ssi < theTrigger )
			pSharedMemory->npos2[ssi][24] = tready;
		else
		{
			if (ssi < (mainSize-25))
			{
				if (pSharedMemory->npos2[ssi - 1][24] < ttrigger)
					pSharedMemory->npos2[ssi][24] = pSharedMemory->npos2[ssi - 1][24] + 1.0;
				else
					pSharedMemory->npos2[ssi][24] = ttrigger;
			}
			else
			{
				if(pSharedMemory->npos2[ssi-1][24] > tready)
					pSharedMemory->npos2[ssi][24] = pSharedMemory->npos2[ssi - 1][24] - 1.0;
				else
					pSharedMemory->npos2[ssi][24] = tready;
			}
		}	
				

		
		/*
		if( ssi < pSharedMemory->dml_trigger_t )
		{
			pSharedMemory->npos2[ssi][24] = pSharedMemory->dml_rwp_ready;//((1)*sRwp)* (180.0/3.14);
		}
		else if( ssi == pSharedMemory->dml_trigger_t )
		{
			pSharedMemory->npos2[ssi][24] = pSharedMemory->dml_rwp_ready/2.0;//((1)*sRwp)* (180.0/3.14);
		}
		else if( ssi > (pSharedMemory->dml_trigger_t - 2) )
		{
			pSharedMemory->npos2[ssi][24] = pSharedMemory->dml_rwp_ready;//((1)*sRwp)* (180.0/3.14);
		}
		else
		{
			pSharedMemory->npos2[ssi][24] = pSharedMemory->dml_rwp_trigger;//((1)*sRwp)* (180.0/3.14);
		}
		*/
    	
    }





	int a = pSharedMemory->dml_pre_stop;
   	for (int sssi=0;sssi<waveSize;sssi++){
	         
   fscanf(fp3,"%f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f",&ship, &sLhy, &sLhr, &sLhp, &sLnp, &sLap, &sLar, &sRhy, &sRhr, &sRhp, &sRnp, &sRap, &sRar, &sLsp, &sLsr, &sLsy, &sLe, &sRsp, &sRsr, &sRsy, &sRe, &sLwp, &sLwr, &sRwp, &sRwr, &sRwy, &sRhn);		
/*
	    pSharedMemory->npos3[sssi][0] = ((-1)*ship)* (180.0/3.14);
    	pSharedMemory->npos3[sssi][1] =  ((1)*sLhy)* (180.0/3.14);
    	pSharedMemory->npos3[sssi][2] =  ((1)*sLhr)* (180.0/3.14)*(-1.0);
    	pSharedMemory->npos3[sssi][3] =  ((1)*sLhp)* (180.0/3.14)*(-1.0) *(1.0);
    	pSharedMemory->npos3[sssi][4] =  ((1))*sLnp* (180.0/3.14);
    	pSharedMemory->npos3[sssi][5] =  ((1)*sLap)* (180.0/3.14)*(-1.0);
    	pSharedMemory->npos3[sssi][6] =  ((1)*sLar)* (180.0/3.14)*(-1.0);
    	pSharedMemory->npos3[sssi][7] =  ((1)*sRhy)* (180.0/3.14);
    	pSharedMemory->npos3[sssi][8] = ((1)*sRhr)* (180.0/3.14); 
    	pSharedMemory->npos3[sssi][9] = ((1)*sRhp)* (180.0/3.14)*(-1.0)*(1.0);
    	pSharedMemory->npos3[sssi][10] =  ((1)*sRnp)* (180.0/3.14);
    	pSharedMemory->npos3[sssi][11] =  ((1)*sRap)* (180.0/3.14)*(-1.0);
    	pSharedMemory->npos3[sssi][12] = ((1)*sRar)* (180.0/3.14)*(-1.0);
*/

		pSharedMemory->npos3[sssi][0] =  0.0;//((-1)*ship)* (180.0/3.14);
    	pSharedMemory->npos3[sssi][1] =  pSharedMemory->npos[a][1];
    	pSharedMemory->npos3[sssi][2] =  pSharedMemory->npos[a][2];
    	pSharedMemory->npos3[sssi][3] =  pSharedMemory->npos[a][3];
    	pSharedMemory->npos3[sssi][4] =  pSharedMemory->npos[a][4];
    	pSharedMemory->npos3[sssi][5] =  pSharedMemory->npos[a][5];
    	pSharedMemory->npos3[sssi][6] =  pSharedMemory->npos[a][6];
    	pSharedMemory->npos3[sssi][7] =  pSharedMemory->npos[a][7];
    	pSharedMemory->npos3[sssi][8] =  pSharedMemory->npos[a][8];
    	pSharedMemory->npos3[sssi][9] =  pSharedMemory->npos[a][9];
    	pSharedMemory->npos3[sssi][10] = pSharedMemory->npos[a][10];
    	pSharedMemory->npos3[sssi][11] = pSharedMemory->npos[a][11];
    	pSharedMemory->npos3[sssi][12] = pSharedMemory->npos[a][12];


		pSharedMemory->npos3[sssi][13] = ((-1)*sLsp)* (180.0/3.14);
    	pSharedMemory->npos3[sssi][14] = ((-1))*sLsr* (180.0/3.14);
    	pSharedMemory->npos3[sssi][15] =  ((-1)*sLsy)* (180.0/3.14);	// hand
    	pSharedMemory->npos3[sssi][16] = ((-1)*sLe)* (180.0/3.14);
    	pSharedMemory->npos3[sssi][17] =  ((-1)*sRsp)* (180.0/3.14) * 0.3;
    	pSharedMemory->npos3[sssi][18] = ((-1)*sRsr)* (180.0/3.14) * 0.3;
    	pSharedMemory->npos3[sssi][19] = ((1)*sRsy)* (180.0/3.14) * 0.3;
    	pSharedMemory->npos3[sssi][20] =  ((-1)*sRe)* (180.0/3.14)+(18.0) * 0.3;	// hand
    	pSharedMemory->npos3[sssi][21] =  0;//((1)*sLwp)* (180.0/3.14);
    	pSharedMemory->npos3[sssi][22] =  0;//((-1)*sLwr)* (180.0/3.14);
	    pSharedMemory->npos3[sssi][23] = 30.0; //RWY  //((1)*sRwp)* (180.0/3.14);
    	pSharedMemory->npos3[sssi][24] = pSharedMemory->dml_rwp_ready;//((-1)*sRwr)* (180.0/3.14);
    }



    CString strTemp;

	GetDlgItem(IDC_THROW_BUTTON)->GetWindowText(strTemp);
	
	if(strTemp == "Throw")
	{
		GetDlgItem(IDC_THROW_BUTTON)->SetWindowText("Throw Off");
        if(pSharedMemory->CommandFlag == NO_ACT)
		pSharedMemory->CommandFlag = THROW;
	}
	else
	{
		GetDlgItem(IDC_THROW_BUTTON)->SetWindowText("Throw");
        if(pSharedMemory->CommandFlag == NO_ACT)
		pSharedMemory->CommandFlag = THROW_OFF;
		
	}

	
}

void CUserDlg::OnBall() 
{
	// TODO: Add your control notification handler code here
	if(pSharedMemory->CommandFlag == NO_ACT)
		pSharedMemory->CommandFlag = BALL;
	
}

void CUserDlg::OnRightWristFetOn() 
{
	// TODO: Add your control notification handler code here
	pSharedMemory->dml_FetOn = true;
	
}

void CUserDlg::OnRwCtrlOn() 
{
	// TODO: Add your control notification handler code here

	pSharedMemory->dml_CtrlOn = true;
	
}

void CUserDlg::OnInitHand() 
{
	// TODO: Add your control notification handler code here

	if(pSharedMemory->CommandFlag == NO_ACT)
	{
		pSharedMemory->JointID = RF1;
		pSharedMemory->CommandFlag = GOTO_LIMIT_POS;
		Sleep(10);
		pSharedMemory->JointID = LF1;
		pSharedMemory->CommandFlag = GOTO_LIMIT_POS;
		Sleep(10);
		pSharedMemory->CommandFlag = C_CONTROL_MODE;
	}
	else AfxMessageBox("Other Command is activated..!!");
	
}

void CUserDlg::OnCloseFinger() 
{
	// TODO: Add your control notification handler code here
	pSharedMemory->dml_finger = 1;
	
}

void CUserDlg::OnOpenFinger() 
{
	// TODO: Add your control notification handler code here
	pSharedMemory->dml_finger = 2;
	
}

void CUserDlg::OnFingerOff() 
{
	// TODO: Add your control notification handler code here
	pSharedMemory->dml_finger = 0;
	
}

void CUserDlg::OnWave() 
{
	// TODO: Add your control notification handler code here
	if(pSharedMemory->CommandFlag == NO_ACT)
		pSharedMemory->CommandFlag = WAVE;	
}

void CUserDlg::OnWaveLoop() 
{
	// TODO: Add your control notification handler code here
		
	if(pSharedMemory->dml_wave_loop)	// if wave loop is on
	{
		
		GetDlgItem(IDC_WaveLoop)->SetWindowText("Turn Wave Loop On");
		pSharedMemory->dml_wave_loop = false;
		
	}
	else
	{
		GetDlgItem(IDC_WaveLoop)->SetWindowText("Turn Wave Loop Off");
		pSharedMemory->dml_wave_loop = true;

	}
	
}

void CUserDlg::OnWstFetOn() 
{
	// TODO: Add your control notification handler code here
	pSharedMemory->dml_FetOn_WST = true;
	
}

void CUserDlg::OnWSTCTRLOn() 
{
	// TODO: Add your control notification handler code here
	pSharedMemory->dml_CtrlOn_WST = true;
	
}
